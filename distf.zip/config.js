const CONFIG = {
    EXTPAY_ID: 'gmail-trimless'
};
